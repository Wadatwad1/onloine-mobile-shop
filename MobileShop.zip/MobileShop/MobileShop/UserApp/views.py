from django.shortcuts import render,redirect
from django.http import HttpResponse
from AdminApp.models import Mobile,Category,UserInfo,MyCart,Accounts,OrderMaster
from datetime import datetime
from django.contrib import messages


def home(request):
    #It will fetch all objects from database
    cats = Category.objects.all()
    mobiles = Mobile.objects.all()
    return render(request,"master.html",{'cats':cats,'mobiles':mobiles})

def ShowMobiles(request,cid):
    cats = Category.objects.all()
    #We need cakes filtered based on category
    #cid is id of selected Category
    #Fetch the object of that category
    cat = Category.objects.get(id=cid)
    mobiles = Mobile.objects.filter(category = cat)
    return render(request,"master.html",{'cats':cats,'mobiles':mobiles})

def ViewDetails(request,id):
    mobile = Mobile.objects.get(id=id)
    cats = Category.objects.all()
    return render(request,"viewdetails.html",{"mobile":mobile,"cats":cats})


def login(request):
    if(request.method=="GET"):
        return render(request,"Login.html",{})
    else:
        uname = request.POST["uname"]
        pwd = request.POST["pwd"]
        try:
            u1 = UserInfo.objects.get(username=uname,password=pwd)
        except:
            return HttpResponse("Invalid Credentials..")
        else:
            request.session["uname"]=uname
            return redirect(home)
            #return HttpResponse("Login Successful")


def signup(request):
    if(request.method=="GET"):
        return render(request,"SignUp.html",{})
    else:
        uname = request.POST["uname"]
        pwd = request.POST["pwd"]
         #check if user already exists
        try:
            u1 = UserInfo.objects.get(username=uname)
        except:
            #Create model object
            u1 = UserInfo(uname,pwd)
            u1.save()
            return redirect(home)
        else:
            return HttpResponse("User Already Present")


def AddToCart(request):
    if(request.method=="POST"):
        #Check if session is created
        if("uname" in request.session):
            #Add To cart
            qty = request.POST["qty"]
            uname = request.session["uname"]
            mobileid = request.POST["mobileid"]
            mobile = Mobile.objects.get(id=mobileid)
            user = UserInfo.objects.get(username = uname)
            #First check that item is not a duplicate
            try:
                cart = MyCart.objects.get(user=user,mobile=mobile)
            except: 
                cart = MyCart()
                cart.user = user
                cart.mobile = mobile
                cart.qty = qty
                cart.save()
                return HttpResponse("Added to Cart..")
            else:
                return HttpResponse("Item already in cart")

        else:
            return redirect(login)

def logout(request):
    request.session.clear()
    return redirect(home)      


def ShowAllCartItems(request):
    user = UserInfo.objects.get(username = request.session["uname"])
    if(request.method == "GET"):        
        items = MyCart.objects.filter(user=user)
        total = 0
        for item in items:
            total += item.qty*item.mobile.price
        
        request.session["total"] = total
        return render(request,"ShowAllCartItems.html",{"items":items})
    else:
        #Check if Update button was clicked or Remove was clicked
        action = request.POST["action"]
        mobileid = request.POST["mobileid"]
        mobile = Mobile.objects.get(id=mobileid)
        item = MyCart.objects.get(user = user,mobile=mobile)

        if(action == "Remove"):
            item.delete()
        elif(action == "Update"):
            qty = request.POST["qty"]
            item.qty = qty
            item.save()
        return redirect(ShowAllCartItems)


def MakePayment(request):
    if(request.method == "GET"):
        return render(request,"MakePayment.html",{})
    else:
        cardno = request.POST["cardno"]
        cvv = request.POST["cvv"]
        expiry = request.POST["expiry"]
        #Check for card validity
        try:
            customer_acc = Accounts.objects.get(cardNo=cardno,cvv=cvv,expiry=expiry)
        except:
            return HttpResponse("Invalid card Details")
        else:
            #Perform transaction
            customer_acc.balance -= request.session["total"]
            owner_acc = Accounts.objects.get(cardNo='111',cvv='111',expiry='12/2030')
            owner_acc.balance+=request.session["total"]
            owner_acc.save()
            customer_acc.save()
            #Clear the cart
            order = OrderMaster()
            user = UserInfo.objects.get(username = request.session["uname"])
            items = MyCart.objects.filter(user=user)
            m_name = ""
            for item in items:
                m_name += item.mobile.mobilename+","
                item.delete()
            #print(m_name)
            order.user = user
            order.cake_details = m_name
            order.total_amount = request.session["total"]
            order.date_of_order = datetime.now()
            order.save()
            return HttpResponse("Payment Successful")


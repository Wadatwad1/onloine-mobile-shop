from django.contrib import admin
from AdminApp.models import Category, Mobile

# Register your models here.
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id','cname')

class MobileAdmin(admin.ModelAdmin):
    list_display = ('id','mobilename','price','discription','image','category')

class AuthorAdmin(admin.ModelAdmin):
    pass
admin.site.register(Category,CategoryAdmin)
admin.site.register(Mobile,MobileAdmin)